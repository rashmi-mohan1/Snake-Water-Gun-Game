# Snake Water Gun With HTML CSS and JS

Made this snake water gun with the help of HTML, CSS and Vanilla Javascript


## Demo

https://user-images.githubusercontent.com/68494604/117431738-33b57180-af47-11eb-9d0f-62a35987c582.mp4



